#!/usr/bin/env python3
import re

js = open('game.js').read()
html = open('index.html').read()

# Check all getElementById calls
gets = re.findall(r'getElementById\(["\']([^"\']+)["\']\)', js)
print('JS references these IDs:')
for g in sorted(set(gets)):
    print(f'  {g}')
print()

ids = re.findall(r'id="([^"]+)"', html)
print('HTML has these IDs:')
for i in ids:
    print(f'  {i}')
print()

missing = set(gets) - set(ids)
if missing:
    print('MISSING in HTML:', missing)
else:
    print('All IDs match OK')

# Check brace balance
opens = js.count('{')
closes = js.count('}')
print(f'\nBrace balance: {{ = {opens}, }} = {closes}, diff = {opens - closes}')
