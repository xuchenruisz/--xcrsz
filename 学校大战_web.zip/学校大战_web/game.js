/* =========================================================
   学校大战 School Battle (HTML5 Canvas · 单人/双人合作)
   ========================================================= */
(function(){
'use strict';

var LW = 480, LH = 360;
var canvas = document.getElementById('game');
canvas.width = LW; canvas.height = LH;
var ctx = canvas.getContext('2d');

// ---- helpers ----
function rand(a,b){ return Math.random()*(b-a)+a; }
function randInt(a,b){ return Math.floor(rand(a,b+1)); }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }

var C = {
  W:'#fff', K:'#111', R:'#e74c3c', B:'#3498db', G:'#4caf50',
  Y:'#f1c40f', O:'#e67e22', P:'#9b59b6', S:'#f5c9a0',
  SK:'#5cc8ff', GD:'#ffd966'
};

var ST = { INTRO:0, BATTLE:1, DEAD:2, WIN:3, PAUSE:4 };

// ---- input ----
var keys = {};
window.addEventListener('keydown', function(e){
  keys[e.code] = true;
  if(e.code==='Digit1') game.startSolo();
  if(e.code==='Digit2') game.startCoop();
  if(e.code==='Enter') game.onEnter();
  if(e.code==='KeyP') game.onPause();
  if(e.code==='KeyQ') game.onSkill(0);
  if(e.code==='KeyK') game.onSkill(1);
  if(['Space','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].indexOf(e.code)>=0) e.preventDefault();
});
window.addEventListener('keyup', function(e){ keys[e.code]=false; });

// ---- DOM cache (called once, stored) ----
var dom = {};
function cacheDom(){
  var $=function(id){return document.getElementById(id);};
  dom.intro = $('overlay-intro');
  dom.win = $('overlay-win');
  dom.dead = $('overlay-dead');
  dom.pause = $('overlay-pause');
  dom.hudSolo = $('hud-solo');
  dom.hudCoop = $('hud-coop');
  dom.soloHP = $('hp-bar');
  dom.soloHPT = $('hp-text');
  dom.soloBul = $('bullets-count');
  dom.soloScore = $('score');
  dom.soloFloor = $('floor');
  dom.soloKill = $('kill-progress');
  dom.soloSkill = $('skill');
  dom.soloName = $('player-name');
  dom.soloShield = $('shield-indicator');
  dom.soloShieldT = $('shield-time');
  dom.p1HP = $('p1-hp-bar');
  dom.p1HPT = $('p1-hp-text');
  dom.p1Bul = $('p1-bullets');
  dom.p1Skill = $('p1-skill');
  dom.p1Shield = $('p1-shield');
  dom.p1ShieldT = $('p1-shield-time');
  dom.p2HP = $('p2-hp-bar');
  dom.p2HPT = $('p2-hp-text');
  dom.p2Bul = $('p2-bullets');
  dom.p2Skill = $('p2-skill');
  dom.p2Shield = $('p2-shield');
  dom.p2ShieldT = $('p2-shield-time');
  dom.coopFloor = $('coop-floor');
  dom.coopScore = $('coop-score');
  dom.coopKill = $('coop-kill');
  dom.coopTarget = $('coop-target');
  dom.winTitle = $('win-title');
  dom.winRewards = $('win-rewards');
  dom.finalScore = $('final-score');
  dom.finalFloor = $('final-floor');
  dom.deadTitle = $('dead-title');
}
cacheDom();

// buttons
document.getElementById('btn-start-solo').onclick = function(){ game.startSolo(); };
document.getElementById('btn-start-coop').onclick = function(){ game.startCoop(); };
document.getElementById('btn-next').onclick = function(){ game.advanceFloor(); };
document.getElementById('btn-restart').onclick = function(){ game.backToMenu(); };
document.getElementById('btn-resume').onclick = function(){ game.onPause(); };

// ---- Particle ----
function Particle(x,y,o){
  this.x=x; this.y=y;
  this.vx=o&&o.vx||0; this.vy=o&&o.vy||0;
  this.life=o&&o.life||0.3; this.max=this.life;
  this.color=o&&o.color||C.W; this.size=o&&o.size||3;
}
Particle.prototype.update=function(dt){this.x+=this.vx;this.y+=this.vy;this.vx*=0.94;this.vy*=0.94;this.life-=dt;};
Particle.prototype.draw=function(c){
  var a=Math.max(0,this.life/this.max), s=Math.max(1,this.size*a);
  c.save(); c.globalAlpha=a; c.fillStyle=this.color;
  c.beginPath(); c.arc(this.x,this.y,s,0,Math.PI*2); c.fill(); c.restore();
};

// ---- Player ----
function Player(x,y,variant){
  this.x=x; this.y=y;
  this.variant=variant||0;
  this.speed=130; this.anim=0; this.facing=1;
}
Player.prototype.update=function(dt,mx,my){
  if(mx<0) this.facing=-1; else if(mx>0) this.facing=1;
  if(mx||my){ this.anim+=dt*8; var L=Math.hypot(mx,my)||1; this.x+=mx/L*this.speed*dt; this.y+=my/L*this.speed*dt; }
  this.x=clamp(this.x,18,LW-18); this.y=clamp(this.y,55,315);
};
Player.prototype.draw=function(c){
  var v=this.variant, bx=this.x, by=this.y+12;
  var sc=v===0?'#3498db':'#e74c3c', sd=v===0?'#2980b9':'#b03a2e';
  // shadow
  c.save(); c.globalAlpha=0.35; c.fillStyle=C.K;
  c.beginPath(); c.ellipse(bx,by+19,12,2.5,0,0,Math.PI*2); c.fill(); c.restore();
  // pants
  c.fillStyle=v===0?'#2c3e50':'#2a2a4a';
  c.fillRect(bx-10,by+4,8,20); c.fillRect(bx+2,by+4,8,20);
  // shirt
  c.fillStyle=sc; c.beginPath(); c.ellipse(bx,by+3,13,10,0,0,Math.PI*2); c.fill();
  c.fillStyle=sd; c.beginPath(); c.moveTo(bx-7,by-6); c.lineTo(bx,by+1); c.lineTo(bx+7,by-6); c.closePath(); c.fill();
  // badge
  c.fillStyle=C.W; c.beginPath(); c.arc(bx,by+3,4,0,Math.PI*2); c.fill();
  c.font='bold 5px sans-serif'; c.textAlign='center'; c.textBaseline='middle';
  c.fillStyle=v===0?'#e74c3c':'#ffd966';
  c.fillText(v===0?'R':'M',bx,by+4);
  // arms
  c.fillStyle=C.S;
  c.beginPath(); c.ellipse(bx-13,by+6,3,8,0,0,Math.PI*2); c.fill();
  c.beginPath(); c.ellipse(bx+13,by+6,3,8,0,0,Math.PI*2); c.fill();
  var hP=Math.sin(this.anim)*2;
  c.beginPath(); c.arc(bx-13,by+14+hP,4,0,Math.PI*2); c.fill();
  c.beginPath(); c.arc(bx+13,by+14-hP,4,0,Math.PI*2); c.fill();
  // head
  c.fillStyle=C.S; c.beginPath(); c.ellipse(bx,by-13,10,11,0,0,Math.PI*2); c.fill();
  c.beginPath(); c.arc(bx-10,by-13,3,0,Math.PI*2); c.fill();
  c.beginPath(); c.arc(bx+10,by-13,3,0,Math.PI*2); c.fill();
  // hair
  c.fillStyle=v===0?'#3d2b1f':'#5a3e2c';
  c.beginPath(); c.ellipse(bx,by-17,11,5.5,0,0,Math.PI*2); c.fill();
  if(v===0){
    c.beginPath(); c.moveTo(bx-11,by-11); c.lineTo(bx-7,by-3); c.lineTo(bx-2,by-7); c.lineTo(bx+3,by-1); c.lineTo(bx+6,by-9); c.lineTo(bx+11,by-4); c.lineTo(bx+11,by-14); c.closePath(); c.fill();
  } else {
    c.fillStyle='#8b3a2a';
    c.beginPath(); c.moveTo(bx-12,by-12); c.lineTo(bx,by-22); c.lineTo(bx+12,by-12); c.closePath(); c.fill();
    c.strokeStyle='#ff4d4d'; c.lineWidth=1.2;
    c.beginPath(); c.moveTo(bx-11,by-16); c.quadraticCurveTo(bx,by-14,bx+11,by-16); c.stroke();
  }
  // eyes
  c.fillStyle=C.W;
  c.beginPath(); c.ellipse(bx-4,by-15,2,2.5,0,0,Math.PI*2); c.fill();
  c.beginPath(); c.ellipse(bx+4,by-15,2,2.5,0,0,Math.PI*2); c.fill();
  c.fillStyle='#2c1810';
  c.beginPath(); c.arc(bx-3.5,by-14.2,1.1,0,Math.PI*2); c.fill();
  c.beginPath(); c.arc(bx+4.5,by-14.2,1.1,0,Math.PI*2); c.fill();
  // blush + mouth
  c.save(); c.globalAlpha=0.4; c.fillStyle='#ffb6a0';
  c.beginPath(); c.ellipse(bx-8,by-9,2.2,1.6,0,0,Math.PI*2); c.fill();
  c.beginPath(); c.ellipse(bx+6,by-9,2.2,1.6,0,0,Math.PI*2); c.fill(); c.restore();
  c.strokeStyle='#c06650'; c.lineWidth=0.9;
  c.beginPath(); c.arc(bx,by-7,3.5,Math.PI+0.1,-0.1,false); c.stroke();
  // shoes
  c.fillStyle=C.W;
  c.beginPath(); c.ellipse(bx-7,by+24,5,2.5,0,0,Math.PI*2); c.fill();
  c.beginPath(); c.ellipse(bx+7,by+24,5,2.5,0,0,Math.PI*2); c.fill();
  c.fillStyle=v===0?C.R:'#2e86de';
  c.fillRect(bx-11,by+22,9,2); c.fillRect(bx+3,by+22,9,2);
  // label
  c.save(); c.font='bold 7px sans-serif'; c.textAlign='center';
  var lb=v===0?'P1':'P2';
  c.fillStyle=v===0?'rgba(92,200,255,0.85)':'rgba(255,120,120,0.85)';
  c.fillRect(bx-10,by-41,20,9);
  c.strokeStyle='#fff'; c.lineWidth=0.5; c.strokeRect(bx-10,by-41,20,9);
  c.fillStyle='#fff'; c.fillText(lb,bx,by-33);
  c.restore();
};

// ---- Bullet ----
function Bullet(x,y,vx,vy,dmg,owner){
  this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.dmg=dmg||10;this.owner=owner||0;
  this.rot=Math.atan2(vy,vx);this.dead=false;
}
Bullet.prototype.update=function(){this.x+=this.vx;this.y+=this.vy;if(this.x<0||this.x>LW||this.y<0||this.y>LH)this.dead=true;};
Bullet.prototype.draw=function(c){
  var col=this.owner===0?[255,200,80]:[255,140,200];
  for(var i=4;i>0;i--){
    var a=(4-i)/4;
    c.save(); c.translate(this.x-i*this.vx*0.3,this.y-i*this.vy*0.3); c.rotate(-this.rot);
    c.globalAlpha=a; c.fillStyle='rgba('+col[0]+','+col[1]+','+col[2]+',1)';
    c.beginPath(); c.ellipse(0,0,6,3,0,0,Math.PI*2); c.fill(); c.restore();
  }
  c.fillStyle=this.owner===0?C.Y:'#ffb6d5';
  c.beginPath(); c.arc(this.x,this.y,2,0,Math.PI*2); c.fill();
  c.fillStyle=C.W; c.beginPath(); c.arc(this.x,this.y,1,0,Math.PI*2); c.fill();
};

// ---- Enemy ----
function Enemy(x,y,hp,sp,variant){
  this.x=x;this.y=y;this.hp=hp;this.hpMax=hp;this.sp=sp;this.variant=variant;
  this.anim=Math.random()*Math.PI*2;this.dead=false;this.skillHit=0;
  var pal=[['#8e44ad','#9b59b6','#f5b041'],['#783c32','#965046','#c88c3c'],['#32508c','#466eb4','#e6a046']];
  var p=pal[(variant-1)%3]; this.c1=p[0]; this.c2=p[1]; this.bc=p[2];
}
Enemy.prototype.update=function(dt,players){
  this.anim+=dt*5;
  var best=players[0],bd=1e9;
  for(var i=0;i<players.length;i++){var d=(players[i].x-this.x)**2+(players[i].y-this.y)**2;if(d<bd){bd=d;best=players[i];}}
  var dx=best.x-this.x,dy=best.y-this.y,L=Math.hypot(dx,dy)||1;
  this.x+=dx/L*this.sp+Math.sin(this.anim)*0.2;
  this.y+=dy/L*this.sp+Math.cos(this.anim)*0.2;
};
Enemy.prototype.draw=function(c){
  var ph=Math.sin(this.anim)*2, bx=this.x, by=this.y;
  c.save();c.globalAlpha=0.35;c.fillStyle='#000';c.beginPath();c.ellipse(bx,by+34,18,3,0,0,Math.PI*2);c.fill();c.restore();
  c.fillStyle=this.c1;c.beginPath();c.ellipse(bx,by+5,18,22,0,0,Math.PI*2);c.fill();
  c.fillStyle=this.c2;c.beginPath();c.ellipse(bx,by+6,14,19,0,0,Math.PI*2);c.fill();
  c.fillStyle=this.bc;c.beginPath();c.ellipse(bx,by+15,9,12,0,0,Math.PI*2);c.fill();
  c.fillStyle=this.c1;c.beginPath();c.ellipse(bx-7,by+30,3,7,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(bx+7,by+30,3,7,0,0,Math.PI*2);c.fill();
  c.fillStyle='#1c2833';c.beginPath();c.ellipse(bx-9,by+37,5,2.5,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(bx+9,by+37,5,2.5,0,0,Math.PI*2);c.fill();
  c.fillStyle=C.W;
  [-10,-7,-4].forEach(function(dx){c.beginPath();c.moveTo(bx+dx,by+37);c.lineTo(bx+dx-1,by+41);c.lineTo(bx+dx+2,by+39);c.closePath();c.fill();});
  [4,7,10].forEach(function(dx){c.beginPath();c.moveTo(bx+dx,by+37);c.lineTo(bx+dx-1,by+41);c.lineTo(bx+dx+2,by+39);c.closePath();c.fill();});
  c.fillStyle=this.c1;c.beginPath();c.ellipse(bx,by-15,18,17,0,0,Math.PI*2);c.fill();
  c.fillStyle=this.c2;c.beginPath();c.ellipse(bx,by-14,15,15,0,0,Math.PI*2);c.fill();
  // ears
  c.save();c.translate(bx-14,by-18);c.rotate(-0.35);c.fillStyle=this.c1;c.beginPath();c.ellipse(0,0,5,9,0,0,Math.PI*2);c.fill();c.fillStyle='#c39bd3';c.beginPath();c.ellipse(0,0,2.8,6.5,0,0,Math.PI*2);c.fill();c.restore();
  c.save();c.translate(bx+14,by-18);c.rotate(0.35);c.fillStyle=this.c1;c.beginPath();c.ellipse(0,0,5,9,0,0,Math.PI*2);c.fill();c.fillStyle='#c39bd3';c.beginPath();c.ellipse(0,0,2.8,6.5,0,0,Math.PI*2);c.fill();c.restore();
  // horns
  var dh=function(hx,hy,d){c.fillStyle=C.Y;c.beginPath();c.moveTo(hx,hy);c.lineTo(hx-d*5,hy-12);c.lineTo(hx-d*10,hy-14);c.lineTo(hx-d*3,hy-4);c.closePath();c.fill();c.fillStyle=C.W;c.beginPath();c.arc(hx-d*10,hy-14,1,0,Math.PI*2);c.fill();};
  dh(bx-13,by-24,-1);dh(bx+13,by-24,1);
  c.fillStyle=C.Y;[-8,0,8].forEach(function(sx){c.beginPath();c.moveTo(bx+sx-2,by-28);c.lineTo(bx+sx,by-38);c.lineTo(bx+sx+2,by-28);c.closePath();c.fill();});
  // brows+eyes
  c.strokeStyle='#2c133a';c.lineWidth=1.5;c.beginPath();c.moveTo(bx-16,by-22);c.lineTo(bx-4,by-18);c.moveTo(bx+16,by-22);c.lineTo(bx+4,by-18);c.stroke();
  c.fillStyle=C.K;c.fillRect(bx-12,by-20,5,4.5);c.fillRect(bx+7,by-20,5,4.5);
  c.fillStyle=C.R;c.beginPath();c.ellipse(bx-10,by-18,4.5,3.5,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(bx+9,by-18,4.5,3.5,0,0,Math.PI*2);c.fill();
  c.fillStyle=C.Y;c.beginPath();c.arc(bx-9+ph*0.3,by-17,1.5,0,Math.PI*2);c.fill();c.beginPath();c.arc(bx+10+ph*0.3,by-17,1.5,0,Math.PI*2);c.fill();
  c.fillStyle=C.K;c.beginPath();c.arc(bx-9+ph*0.3,by-17,0.9,0,Math.PI*2);c.fill();c.beginPath();c.arc(bx+10+ph*0.3,by-17,0.9,0,Math.PI*2);c.fill();
  // nose+mouth+fangs
  c.fillStyle='#2c133a';c.beginPath();c.ellipse(bx,by-8,2.5,1.8,0,0,Math.PI*2);c.fill();
  c.fillStyle=C.K;c.beginPath();c.ellipse(bx,by-2,13,8,0,0,Math.PI*2);c.fill();
  c.fillStyle=C.W;
  [[-10,9],[-4,11],[2,11],[8,9]].forEach(function(v){c.beginPath();c.moveTo(bx+v[0],by-2);c.lineTo(bx+v[0]+2,by-2+v[1]);c.lineTo(bx+v[0]+4,by-2);c.closePath();c.fill();});
  [[-7,9],[-1,11],[5,9]].forEach(function(v){c.beginPath();c.moveTo(bx+v[0],by+6);c.lineTo(bx+v[0]+2,by+6-v[1]);c.lineTo(bx+v[0]+4,by+6);c.closePath();c.fill();});
  c.fillStyle=C.R;c.beginPath();c.moveTo(bx-5,by+5);c.quadraticCurveTo(bx,by+10,bx+5,by+5);c.closePath();c.fill();
  // arm+bayonet
  c.fillStyle=this.c2;c.beginPath();c.ellipse(bx-18,by-2,4,14,0,0,Math.PI*2);c.fill();c.beginPath();c.arc(bx-18,by+12,5,0,Math.PI*2);c.fill();
  var hx2=bx-20,hy2=by+14;
  c.fillStyle='#5d4037';c.fillRect(hx2-1,hy2-14,8,4);c.fillStyle='#8b4513';c.fillRect(hx2,hy2-10,6,12);
  c.strokeStyle='#5d4037';c.lineWidth=0.6;[-7,-3,1].forEach(function(yy){c.beginPath();c.moveTo(hx2,hy2+yy);c.lineTo(hx2+6,hy2+yy+2);c.stroke();});
  c.fillStyle='#b8860b';c.fillRect(hx2-3,hy2+1,14,3);c.fillStyle='#ffd700';c.beginPath();c.arc(hx2-1,hy2+2.5,0.7,0,Math.PI*2);c.fill();c.beginPath();c.arc(hx2+8,hy2+2.5,0.7,0,Math.PI*2);c.fill();
  c.save();c.translate(hx2+3,hy2+22);c.rotate(-0.87);
  var g1=c.createLinearGradient(0,0,8,0);g1.addColorStop(0,'#d5dbdb');g1.addColorStop(0.5,'#ecf0f1');g1.addColorStop(1,'#95a5a6');c.fillStyle=g1;
  c.beginPath();c.moveTo(0,0);c.lineTo(8,0);c.lineTo(6,70);c.lineTo(4,78);c.lineTo(2,78);c.lineTo(0,70);c.closePath();c.fill();
  c.strokeStyle='#95a5a6';c.lineWidth=1;c.beginPath();c.moveTo(4,10);c.lineTo(4,65);c.stroke();c.restore();
  c.fillStyle=this.c2;c.beginPath();c.ellipse(bx+18,by,4,12,0,0,Math.PI*2);c.fill();
  c.fillStyle=this.c1;c.beginPath();c.arc(bx+22,by+12,6,0,Math.PI*2);c.fill();
  // hp
  if(this.hp<this.hpMax){var bw=30;c.fillStyle='#2a0a0a';c.fillRect(bx-bw/2,by-40,bw,4);c.fillStyle=C.R;c.fillRect(bx-bw/2,by-40,bw*Math.max(0,this.hp/this.hpMax),4);c.strokeStyle='#000';c.lineWidth=0.5;c.strokeRect(bx-bw/2,by-40,bw,4);}
};

// ---- SkillBlast ----
function SkillBlast(x,y,r,dmg,owner){
  this.x=x;this.y=y;this.tr=r;this.r=8;this.dmg=dmg;this.owner=owner||0;
  this.ml=0.6;this.life=0.6;this.id=Math.random();
}
SkillBlast.prototype.update=function(dt){this.life-=dt;this.r+=(this.tr-this.r)*0.2;};
SkillBlast.prototype.draw=function(c){
  var a=Math.max(0,this.life/this.ml), col=this.owner===0?C.SK:'#ff7aa6';
  c.save();c.globalAlpha=a*0.7;c.strokeStyle=col;c.lineWidth=5;
  c.beginPath();c.arc(this.x,this.y,this.r,0,Math.PI*2);c.stroke();
  c.fillStyle=this.owner===0?'rgba(200,240,255,0.3)':'rgba(255,210,230,0.3)';
  c.beginPath();c.arc(this.x,this.y,this.r-8,0,Math.PI*2);c.fill();c.restore();
};

// ---- HealItem ----
function HealItem(x,y,amt){
  this.x=x;this.y=y;this.by=y;this.amt=amt||25;
  this.ml=15;this.life=15;this.anim=Math.random()*Math.PI*2;
  this.kind=Math.random()<0.5?'h':'p';this.dead=false;
}
HealItem.prototype.update=function(dt){this.life-=dt;this.anim+=dt*4;this.y=this.by+Math.sin(this.anim)*2.5;if(this.life<=0)this.dead=true;};
HealItem.prototype.draw=function(c){
  var b=this.life<3?0.5+0.5*Math.sin(this.anim*3):1;
  c.save();c.globalAlpha=b;
  c.save();c.translate(this.x,this.y);
  c.globalAlpha=b*0.5;c.fillStyle='#ffe6ea';c.beginPath();c.arc(0,0,14,0,Math.PI*2);c.fill();
  c.globalAlpha=b;
  if(this.kind==='h'){
    c.fillStyle=C.R;c.beginPath();c.arc(-6,-5,6,0,Math.PI*2);c.arc(6,-5,6,0,Math.PI*2);c.moveTo(-12,-4);c.lineTo(12,-4);c.lineTo(0,12);c.closePath();c.fill();
    c.fillStyle='rgba(255,220,220,0.9)';c.beginPath();c.arc(-7,-7,2,0,Math.PI*2);c.fill();
  } else {
    c.fillStyle='#646464';c.fillRect(-6,-15,12,5);c.fillStyle='#c8c8c8';c.fillRect(-4,-10,8,3);
    c.fillStyle=C.R;c.beginPath();c.ellipse(0,2,10,10,0,0,Math.PI*2);c.fill();c.fillRect(-9,-7,18,10);
    c.fillStyle='rgba(255,220,220,0.8)';c.beginPath();c.ellipse(-5,-2,2,5,0,0,Math.PI*2);c.fill();
    c.fillStyle=C.W;c.fillRect(-2,0,4,10);c.fillRect(-5,3,10,4);
  }
  c.restore();
  c.fillStyle='#ff5064';c.font='bold 10px sans-serif';c.textAlign='center';c.fillText('+'+this.amt,this.x,this.y+(this.kind==='h'?16:17));
  c.restore();
};

// ---- ShieldItem ----
function ShieldItem(x,y,dur){
  this.x=x;this.y=y;this.by=y;this.dur=dur||5;
  this.ml=14;this.life=14;this.anim=Math.random()*Math.PI*2;this.dead=false;
}
ShieldItem.prototype.update=function(dt){this.life-=dt;this.anim+=dt*5;this.y=this.by+Math.sin(this.anim)*3;if(this.life<=0)this.dead=true;};
ShieldItem.prototype.draw=function(c){
  var b=this.life<3?0.5+0.5*Math.sin(this.anim*3):1;
  c.save();c.translate(this.x,this.y);
  c.globalAlpha=b*0.45;c.fillStyle=C.SK;c.beginPath();c.arc(0,0,19,0,Math.PI*2);c.fill();
  c.globalAlpha=b;
  var pts=[[0,-18],[14,-12],[14,4],[0,20],[-14,4],[-14,-12]];
  c.fillStyle=C.SK;c.beginPath();pts.forEach(function(p,i){i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]);});c.closePath();c.fill();
  c.strokeStyle=C.GD;c.lineWidth=2;c.stroke();
  c.fillStyle=C.GD;c.beginPath();
  for(var i=0;i<10;i++){var ang=(i*36-90)*Math.PI/180,rr=i%2===0?7:3;if(i===0)c.moveTo(Math.cos(ang)*rr,Math.sin(ang)*rr);else c.lineTo(Math.cos(ang)*rr,Math.sin(ang)*rr);}
  c.closePath();c.fill();c.restore();
  c.fillStyle=C.SK;c.font='bold 10px sans-serif';c.textAlign='center';c.fillText(this.dur+'s',this.x,this.y+24);
};

// ---- Backgrounds ----
function drawWin(c,x,y,w,h){c.fillStyle='#87ceeb';c.fillRect(x,y,w,h);c.strokeStyle=C.W;c.lineWidth=3;c.strokeRect(x,y,w,h);c.lineWidth=2;c.beginPath();c.moveTo(x+w/2,y);c.lineTo(x+w/2,y+h);c.stroke();c.beginPath();c.moveTo(x,y+h/2);c.lineTo(x+w,y+h/2);c.stroke();}
function drawBrokenWin(c,x,y,w,h){c.fillStyle='#3a4856';c.fillRect(x,y,w,h);c.strokeStyle='#4a3020';c.lineWidth=4;c.strokeRect(x,y,w,h);c.lineWidth=3;c.beginPath();c.moveTo(x+w/2,y);c.lineTo(x+w/2,y+h);c.stroke();c.beginPath();c.moveTo(x,y+h/2);c.lineTo(x+w,y+h/2);c.stroke();c.fillStyle='#1a1a1a';c.beginPath();c.moveTo(x+55,y+60);c.lineTo(x+70,y+65);c.lineTo(x+62,y+80);c.lineTo(x+75,y+85);c.lineTo(x+58,y+90);c.lineTo(x+50,y+78);c.closePath();c.fill();}
function drawDesk(c,x,y,rot){c.save();c.translate(x+35,y+45);if(rot)c.rotate(rot*Math.PI/180);c.translate(-35,-45);c.fillStyle='#d4a24c';c.fillRect(0,0,70,35);c.fillStyle='#8b7355';c.fillRect(5,35,4,20);c.fillRect(61,35,4,20);c.fillStyle='#c4913b';c.fillRect(10,55,50,8);c.fillStyle='#8b7355';c.fillRect(10,63,4,25);c.fillRect(56,63,4,25);c.restore();}
function drawWeb(c,cx,cy,r,a){c.save();c.translate(cx,cy);c.globalAlpha=a||0.35;c.strokeStyle=C.W;c.lineWidth=0.5;for(var i=0;i<8;i++){var ang=i*Math.PI/4;c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(ang)*r,Math.sin(ang)*r);c.stroke();}[r/3,2*r/3,r].forEach(function(rr){c.beginPath();c.arc(0,0,rr,0,Math.PI*2);c.stroke();});c.restore();}

function drawClassBG(c){
  c.fillStyle='#f5f0e6';c.fillRect(0,0,LW,50);c.fillStyle='#fff8e7';c.fillRect(0,50,LW,200);c.fillStyle='#c4913b';c.fillRect(0,250,LW,110);c.fillStyle='#d4a24c';c.fillRect(0,250,LW,10);
  c.strokeStyle='#b07e2a';c.lineWidth=1;for(var y=270;y<360;y+=20){c.beginPath();c.moveTo(0,y);c.lineTo(LW,y);c.stroke();}
  c.fillStyle='#8b7355';c.fillRect(115,55,250,130);c.fillStyle='#2d5a3d';c.fillRect(120,65,240,120);c.fillStyle='#8b7355';c.fillRect(130,185,220,8);
  c.fillStyle=C.W;c.font='bold 28px "PingFang SC","Microsoft YaHei",sans-serif';c.textAlign='center';c.fillText('\u5B66\u6821\u5927\u6218',240,108);
  c.fillStyle='#ffeb3b';c.font='bold 14px "PingFang SC",sans-serif';c.fillText('\u9009\u6A21\u5F0F\uFF1A\u6309 1 \u5355\u4EBA / 2 \u53CC\u4EBA\u5408\u4F5C',240,140);
  c.fillStyle='#fff';c.font='12px "PingFang SC",sans-serif';
  c.fillText('P1\uFF1AWASD \u79FB\u52A8\u3001\u7A7A\u683C\u5C04\u51FB\u3001Q \u6280\u80FD',240,162);
  c.fillText('P2\uFF1A\u2190\u2191\u2192\u2193 \u79FB\u52A8\u3001J \u5C04\u51FB\u3001K \u6280\u80FD',240,178);
  drawWin(c,20,70,80,100);drawWin(c,380,70,80,100);
  [40,140,270,370].forEach(function(x){drawDesk(c,x,220,0);});
  c.fillStyle='#8b7355';c.fillRect(170,195,140,50);
  c.save();c.translate(240,55);c.fillStyle=C.W;c.beginPath();c.arc(0,0,16,0,Math.PI*2);c.fill();c.strokeStyle=C.K;c.lineWidth=2;c.stroke();c.beginPath();c.moveTo(0,0);c.lineTo(0,-10);c.stroke();c.beginPath();c.moveTo(0,0);c.lineTo(8,3);c.lineWidth=1;c.stroke();c.restore();
}

function drawAbrBG(c){
  c.fillStyle='#8b8070';c.fillRect(0,0,LW,50);c.fillStyle='#5a4a35';c.beginPath();c.ellipse(120,38,30,8,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(350,30,40,10,0,0,Math.PI*2);c.fill();
  c.fillStyle='#c2b280';c.fillRect(0,50,LW,200);c.fillStyle='#6b8e23';c.beginPath();c.ellipse(80,180,35,25,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(420,160,30,35,0,0,Math.PI*2);c.fill();
  c.fillStyle='#4a6b3d';c.beginPath();c.ellipse(300,220,25,20,0,0,Math.PI*2);c.fill();
  c.fillStyle='#8a7a5a';c.beginPath();c.moveTo(180,80);c.lineTo(190,95);c.lineTo(215,85);c.lineTo(235,105);c.lineTo(210,115);c.lineTo(185,105);c.closePath();c.fill();
  c.beginPath();c.moveTo(360,100);c.lineTo(375,120);c.lineTo(400,110);c.lineTo(405,130);c.lineTo(380,135);c.closePath();c.fill();
  c.fillStyle='#7a5c30';c.fillRect(0,250,LW,110);c.fillStyle='#8a6a3a';c.fillRect(0,250,LW,10);
  c.strokeStyle='#4a3520';c.lineWidth=1;for(var y=275;y<360;y+=25){c.beginPath();c.moveTo(0,y);c.lineTo(LW,y);c.stroke();}
  c.fillStyle='#2a1a08';c.beginPath();c.ellipse(150,305,25,10,0,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(380,270,20,6,0,0,Math.PI*2);c.fill();
  drawWeb(c,35,70,38,0.35);drawWeb(c,445,70,40,0.28);drawWeb(c,40,220,28,0.24);
  c.fillStyle='#5a4530';c.fillRect(115,55,250,130);c.fillStyle='#2a2e20';c.fillRect(120,65,240,120);
  c.strokeStyle='#1a1a10';c.lineWidth=0.6;c.beginPath();c.moveTo(150,70);c.lineTo(180,175);c.stroke();c.beginPath();c.moveTo(280,80);c.lineTo(310,170);c.stroke();
  c.fillStyle='#5a4530';c.fillRect(130,185,220,8);c.fillStyle='#dcc8a0';c.beginPath();c.ellipse(408,191,18,3,0,0,Math.PI*2);c.fill();
  drawBrokenWin(c,20,70,80,100);drawBrokenWin(c,380,70,80,100);
  c.save();c.translate(245,228);c.rotate(-3*Math.PI/180);c.fillStyle='#4a3a20';c.fillRect(-30,-32,60,65);c.strokeStyle='#2a1a08';c.lineWidth=1;c.beginPath();c.moveTo(-22,-24);c.lineTo(-8,10);c.stroke();c.fillStyle='#6b5a40';c.beginPath();c.arc(10,3,3,0,Math.PI*2);c.fill();c.restore();
  c.fillStyle='#5a4a30';c.fillRect(170,195,140,50);c.fillStyle='#1a1000';c.beginPath();c.ellipse(240,196,18,4,0,0,Math.PI*2);c.fill();
  drawDesk(c,40,210,15);drawDesk(c,140,220,-5);drawDesk(c,270,215,-8);drawDesk(c,370,210,10);
}

// ---- Slot ----
function mkSlot(n){return {name:n,hp:100,hpMax:100,bul:100,fr:0.3,fcd:0,skLv:1,skCD:0,shT:0};}

// ---- Game ----
var game = {
  st: ST.INTRO, mode:'solo', time:0, floor:1, killTgt:8, killed:0, score:0,
  slots:[mkSlot('ruirui'),mkSlot('mingming')],
  players:[], bullets:[], enemies:[], heals:[], shields:[], blasts:[], parts:[],
  eCD:0, hCD:5, sCD:7, skillStamp:0,

  startSolo:function(){
    if(this.st!==ST.INTRO) return;
    this.mode='solo';
    this.players=[new Player(LW/2,LH/2+30,0)];
    this.slots[0]=mkSlot('ruirui');
    this.st=ST.BATTLE;
    dom.intro.classList.add('hidden');
    dom.hudSolo.classList.remove('hidden'); dom.hudCoop.classList.add('hidden');
    this.resetBattle();
  },
  startCoop:function(){
    if(this.st!==ST.INTRO) return;
    this.mode='coop';
    this.players=[new Player(LW/2-50,LH/2+30,0),new Player(LW/2+50,LH/2+30,1)];
    this.slots[0]=mkSlot('ruirui'); this.slots[1]=mkSlot('mingming');
    this.st=ST.BATTLE;
    dom.intro.classList.add('hidden');
    dom.hudSolo.classList.add('hidden'); dom.hudCoop.classList.remove('hidden');
    this.resetBattle();
  },
  resetBattle:function(){
    this.bullets=[];this.enemies=[];this.heals=[];this.shields=[];this.blasts=[];this.parts=[];
    this.eCD=0;this.hCD=5;this.sCD=7;this.killed=0;
    this.syncDom();
  },
  advanceFloor:function(){
    if(this.st!==ST.WIN) return;
    this.floor++; this.killTgt=8+this.floor*3;
    var self=this;
    this.slots.forEach(function(s,i){
      if(self.mode==='solo'&&i>0) return;
      s.hpMax+=15; s.hp=Math.min(s.hpMax,s.hp+40); s.bul+=40;
      s.fr=Math.max(0.1,s.fr*0.9); s.skLv=Math.min(5,s.skLv+1); s.skCD=0; s.shT=0;
    });
    if(this.mode==='solo'){this.players=[new Player(LW/2,LH/2+30,0)];}
    else{this.players=[new Player(LW/2-50,LH/2+30,0),new Player(LW/2+50,LH/2+30,1)];}
    dom.win.classList.add('hidden');
    this.st=ST.BATTLE; this.resetBattle();
  },
  backToMenu:function(){
    this.st=ST.INTRO; this.mode='solo'; this.time=0; this.floor=1; this.killTgt=8; this.killed=0; this.score=0;
    this.slots=[mkSlot('ruirui'),mkSlot('mingming')]; this.players=[];
    this.bullets=[];this.enemies=[];this.heals=[];this.shields=[];this.blasts=[];this.parts=[];
    this.eCD=0;this.hCD=5;this.sCD=7;this.skillStamp=0;
    dom.intro.classList.remove('hidden'); dom.dead.classList.add('hidden');
    dom.hudSolo.classList.add('hidden'); dom.hudCoop.classList.add('hidden');
    dom.win.classList.add('hidden'); dom.pause.classList.add('hidden');
  },
  onEnter:function(){
    if(this.st===ST.DEAD) this.backToMenu();
    else if(this.st===ST.WIN) this.advanceFloor();
  },
  onPause:function(){
    if(this.st===ST.BATTLE){this.st=ST.PAUSE;dom.pause.classList.remove('hidden');}
    else if(this.st===ST.PAUSE){this.st=ST.BATTLE;dom.pause.classList.add('hidden');}
  },
  onSkill:function(idx){
    if(this.st!==ST.BATTLE) return;
    if(this.mode==='solo'&&idx!==0) return;
    if(idx<0||idx>1) return;
    var s=this.slots[idx], p=this.players[idx];
    if(!p||!s||s.skCD>0) return;
    s.skCD=5-Math.min(3,s.skLv*0.5);
    var rad=50+s.skLv*25, dmg=30+s.skLv*20;
    var b=new SkillBlast(p.x,p.y,rad,dmg,idx);
    this.skillStamp++; b._stamp=this.skillStamp;
    this.blasts.push(b);
    var col=idx===0?C.SK:'#ff80aa';
    for(var i=0;i<36;i++){var a=i*10*Math.PI/180;this.parts.push(new Particle(p.x,p.y,{vx:Math.cos(a)*4,vy:Math.sin(a)*4,life:0.6,color:col,size:4}));}
  },
  fire:function(si){
    var s=this.slots[si], p=this.players[si];
    if(!s||!p||s.bul<=0||s.fcd>0) return;
    s.bul--; s.fcd=s.fr;
    var tx=LW/2,ty=0;
    if(this.enemies.length>0){var best=this.enemies[0],bd=1e9;for(var i=0;i<this.enemies.length;i++){var d=(this.enemies[i].x-p.x)**2+(this.enemies[i].y-p.y)**2;if(d<bd){bd=d;best=this.enemies[i];}}tx=best.x;ty=best.y;}
    var dx=tx-p.x,dy=ty-p.y,L=Math.hypot(dx,dy)||1;
    this.bullets.push(new Bullet(p.x,p.y,dx/L*6,dy/L*6,10,si));
    for(var i=0;i<3;i++) this.parts.push(new Particle(p.x,p.y,{color:si===0?C.Y:'#ffaadd',life:0.15,size:2}));
  },
  spawnEnemy:function(){
    var side=randInt(0,3),m=30,x,y;
    if(side===0||side===2){x=rand(30,LW-30);y=-m;}
    else if(side===1){x=LW+m;y=rand(30,LH-120);}
    else{x=-m;y=rand(30,LH-120);}
    this.enemies.push(new Enemy(x,y,20+Math.floor(this.floor*6),0.6+this.floor*0.08,randInt(1,3)));
  },

  update:function(dt){
    if(this.st!==ST.BATTLE) return;
    this.time+=dt;
    var self=this;
    // player input
    this.players.forEach(function(p,i){
      var s=self.slots[i]; s.fcd=Math.max(0,s.fcd-dt); s.skCD=Math.max(0,s.skCD-dt); s.shT=Math.max(0,s.shT-dt);
      var mx=0,my=0;
      if(i===0){if(keys['KeyA']) mx-=1; if(keys['KeyD']) mx+=1; if(keys['KeyW']) my-=1; if(keys['KeyS']) my+=1;}
      else{if(keys['ArrowLeft']) mx-=1; if(keys['ArrowRight']) mx+=1; if(keys['ArrowUp']) my-=1; if(keys['ArrowDown']) my+=1;}
      p.update(dt,mx,my);
      if(i===0){if(keys['Space']) self.fire(0);}
      else{if(keys['KeyJ']) self.fire(1);}
    });
    // enemies spawn
    this.eCD-=dt;
    var si=Math.max(0.5,2.0-this.floor*0.15);
    if(this.eCD<=0&&this.killed<this.killTgt){this.eCD=si;if(this.enemies.length<3+this.floor+(this.mode==='coop'?2:0))this.spawnEnemy();}
    // heal items
    this.hCD-=dt;
    if(this.hCD<=0){
      this.hCD=rand(7,13);
      var anyLow=this.slots.some(function(s,i){return self.mode==='solo'?i===0&&s.hp<s.hpMax:s.hp<s.hpMax;});
      var maxH=this.mode==='coop'?3:2;
      if(this.heals.length<maxH&&anyLow) this.heals.push(new HealItem(rand(60,LW-60),rand(110,290),[15,20,25,30,40][randInt(0,4)]));
    }
    this.heals.forEach(function(it){it.update(dt);});
    for(var i=this.heals.length-1;i>=0;i--){
      var it=this.heals[i], bestI=-1, bd=1e9;
      for(var j=0;j<this.players.length;j++){
        var d=Math.hypot(this.players[j].x-it.x,this.players[j].y-it.y);
        if(d<18&&d<bd){bd=d;bestI=j;}
      }
      if(bestI>=0){
        var sl=this.slots[bestI]; sl.hp=Math.min(sl.hpMax,sl.hp+it.amt);
        for(var k=0;k<12;k++){var a=Math.random()*Math.PI*2;var sp=rand(0.5,2.5);this.parts.push(new Particle(it.x,it.y-5,{vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-1,life:0.6,color:['#ff788c','#ff5064','#fff'][randInt(0,2)],size:3}));}
        this.heals.splice(i,1);
      }
    }
    // shield items
    this.sCD-=dt;
    if(this.sCD<=0){
      this.sCD=rand(12,18);
      var maxS=this.mode==='coop'?2:1;
      if(this.shields.length<maxS) this.shields.push(new ShieldItem(rand(60,LW-60),rand(110,290),[4,5,5,6,7][randInt(0,4)]));
    }
    this.shields.forEach(function(it){it.update(dt);});
    for(var i=this.shields.length-1;i>=0;i--){
      var it=this.shields[i], bestI=-1, bd=1e9;
      for(var j=0;j<this.players.length;j++){
        var d=Math.hypot(this.players[j].x-it.x,this.players[j].y-it.y);
        if(d<20&&d<bd){bd=d;bestI=j;}
      }
      if(bestI>=0){
        this.slots[bestI].shT=Math.max(this.slots[bestI].shT,it.dur);
        var col=bestI===0?C.SK:'#ffaadd';
        for(var k=0;k<24;k++){var a=k*15*Math.PI/180;this.parts.push(new Particle(it.x,it.y-4,{vx:Math.cos(a)*3,vy:Math.sin(a)*3,life:0.8,color:[col,'#b4f0ff','#fff'][randInt(0,2)],size:4}));}
        this.shields.splice(i,1);
      }
    }
    // bullets + hit
    this.bullets.forEach(function(b){b.update();});
    for(var i=this.bullets.length-1;i>=0;i--){
      var b=this.bullets[i]; if(b.dead) continue;
      for(var j=0;j<this.enemies.length;j++){
        var e=this.enemies[j]; if(e.dead) continue;
        if(Math.hypot(b.x-e.x,b.y-e.y)<20){
          e.hp-=b.dmg; b.dead=true;
          for(var k=0;k<6;k++) this.parts.push(new Particle(b.x,b.y,{color:'#ffc832',life:0.3,size:3}));
          break;
        }
      }
    }
    this.bullets=this.bullets.filter(function(b){return !b.dead;});
    // skill blasts
    this.blasts.forEach(function(s){s.update(dt);});
    for(var i=0;i<this.blasts.length;i++){
      var sk=this.blasts[i];
      if(sk.life>0.9*sk.ml){
        for(var j=0;j<this.enemies.length;j++){
          var e=this.enemies[j]; if(e.dead||e.skillHit===sk._stamp) continue;
          if(Math.hypot(e.x-sk.x,e.y-sk.y)<sk.r){
            e.hp-=sk.dmg; e.skillHit=sk._stamp;
            for(var k=0;k<8;k++) this.parts.push(new Particle(e.x,e.y,{life:0.4,color:sk.owner===0?C.SK:'#ff80aa',size:4}));
          }
        }
      }
    }
    this.blasts=this.blasts.filter(function(s){return s.life>0;});
    // enemies update + touch damage
    this.enemies.forEach(function(e){
      e.update(dt,self.players);
      for(var i=0;i<self.players.length;i++){
        var p=self.players[i],sl=self.slots[i];
        if(Math.hypot(e.x-p.x,e.y-p.y)<22){
          if(sl.shT>0){
            var dx=p.x-e.x,dy=p.y-e.y,L=Math.hypot(dx,dy)||1;
            e.x-=dx/L*0.5;e.y-=dy/L*0.5;
            for(var k=0;k<2;k++) self.parts.push(new Particle(p.x,p.y,{color:i===0?C.SK:'#ffaadd',life:0.15,size:3}));
          } else {
            sl.hp-=18*dt;
            for(var k=0;k<3;k++) self.parts.push(new Particle(p.x,p.y,{color:C.R,life:0.25,size:3}));
          }
        }
      }
      if(e.hp<=0&&!e.dead){
        e.dead=true; self.killed++; self.score+=10*self.floor;
        if(Math.random()<(self.mode==='coop'?0.35:0.30)){var ri=randInt(0,self.players.length-1);self.slots[ri].bul+=randInt(3,8);}
        if(Math.random()<(self.mode==='coop'?0.20:0.15)){var ri=randInt(0,self.players.length-1);self.slots[ri].hp=Math.min(self.slots[ri].hpMax,self.slots[ri].hp+15);}
        for(var k=0;k<14;k++){var a=Math.random()*Math.PI*2,s=rand(1,4);self.parts.push(new Particle(e.x,e.y,{vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:0.6,color:[C.R,C.P,C.Y,C.O][randInt(0,3)],size:4}));}
      }
    });
    this.enemies=this.enemies.filter(function(e){return !e.dead;});
    // particles
    this.parts.forEach(function(p){p.update(dt);});
    this.parts=this.parts.filter(function(p){return p.life>0;});
    // win/lose
    var allAlive=this.slots.every(function(s,i){return self.mode==='solo'?(i===0?s.hp>0:true):s.hp>0;});
    if(!allAlive){
      this.slots.forEach(function(s){if(s.hp<0)s.hp=0;});
      this.st=ST.DEAD;
      dom.finalScore.textContent=this.score; dom.finalFloor.textContent=this.floor;
      dom.deadTitle.textContent=this.mode==='coop'?'\uD83D\uDC80 \u53CC\u4EBA\u5C0F\u961F\u5168\u706D\u2026':'\uD83D\uDC80 \u4F60\u88AB\u602A\u7269\u51FB\u8D25\u4E86...';
      dom.dead.classList.remove('hidden');
      this.players.forEach(function(p){
        for(var i=0;i<22;i++){var a=Math.random()*Math.PI*2,sp=rand(1,5);self.parts.push(new Particle(p.x,p.y,{vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:1.0,color:[C.R,C.O,C.Y][randInt(0,2)],size:5}));}
      });
    } else if(this.killed>=this.killTgt&&this.enemies.length===0){
      this.st=ST.WIN;
      dom.winTitle.textContent='\u7B2C '+this.floor+' \u5C42\u901A\u8FC7\uFF01';
      dom.winRewards.innerHTML=['<li>\u751F\u547D\u4E0A\u9650 +15\uFF08\u6BCF\u4EBA\uFF09</li>','<li>\u5B50\u5F39 +40\uFF08\u6BCF\u4EBA\uFF09</li>','<li>\u5C04\u901F\u63D0\u5347 10%</li>','<li>\u6280\u80FD\u7B49\u7EA7\u63D0\u5347</li>'].join('');
      dom.win.classList.remove('hidden');
    }
    this.syncDom();
  },

  syncDom:function(){
    if(this.mode==='solo'){
      var s=this.slots[0];
      dom.soloHP.style.width=(100*s.hp/s.hpMax)+'%';
      dom.soloHPT.textContent=Math.ceil(s.hp)+' / '+s.hpMax;
      dom.soloBul.textContent=s.bul;
      dom.soloScore.textContent=this.score;
      dom.soloFloor.textContent=this.floor;
      dom.soloKill.textContent=this.killed+' / '+this.killTgt;
      dom.soloName.textContent=s.name;
      dom.soloSkill.textContent=s.skCD<=0?('Lv'+s.skLv+' \u5C31\u7EEA'):('Lv'+s.skLv+' '+s.skCD.toFixed(1)+'s');
      dom.soloSkill.className=s.skCD<=0?'skill-ready':'skill-cooldown';
      if(s.shT>0){dom.soloShield.classList.remove('hidden');dom.soloShieldT.textContent=s.shT.toFixed(1);}
      else dom.soloShield.classList.add('hidden');
    } else {
      var self=this;
      [{s:0,d:{hp:dom.p1HP,hpt:dom.p1HPT,bul:dom.p1Bul,sk:dom.p1Skill,sh:dom.p1Shield,sht:dom.p1ShieldT},hint:'Q'},
       {s:1,d:{hp:dom.p2HP,hpt:dom.p2HPT,bul:dom.p2Bul,sk:dom.p2Skill,sh:dom.p2Shield,sht:dom.p2ShieldT},hint:'K'}
      ].forEach(function(o){
        var s=self.slots[o.s],d=o.d;
        d.hp.style.width=(100*s.hp/s.hpMax)+'%';
        d.hpt.textContent=Math.ceil(s.hp)+'/'+s.hpMax;
        d.bul.textContent=s.bul;
        d.sk.textContent=s.skCD<=0?(o.hint+' Lv'+s.skLv+' \u5C31\u7EEA'):(o.hint+' Lv'+s.skLv+' '+s.skCD.toFixed(1)+'s');
        d.sk.className=s.skCD<=0?'skill-ready':'skill-cooldown';
        if(s.shT>0){d.sh.classList.remove('hidden');d.sht.textContent=s.shT.toFixed(1);}else d.sh.classList.add('hidden');
      });
      dom.coopFloor.textContent=this.floor;
      dom.coopScore.textContent=this.score;
      dom.coopKill.textContent=this.killed;
      dom.coopTarget.textContent=this.killTgt;
    }
  },

  drawShieldFX:function(p,sl,idx){
    if(sl.shT<=0) return;
    var px=p.x,py=p.y+10;
    var pulse=1+0.15*Math.sin(this.time*10);
    var rI=28*pulse,rO=36*pulse;
    var alpha=sl.shT<1?0.85*(0.5+0.5*Math.sin(this.time*20)):0.85;
    ctx.save();ctx.globalAlpha=alpha;
    ctx.strokeStyle=idx===0?C.SK:'#ff7aa6';ctx.lineWidth=4;
    ctx.beginPath();ctx.arc(px,py-8,rO,0,Math.PI*2);ctx.stroke();
    ctx.strokeStyle=C.GD;ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(px,py-8,rI,0,Math.PI*2);ctx.stroke();
    ctx.globalAlpha=alpha*0.4;ctx.fillStyle=idx===0?'#c8f0ff':'#ffd6e7';
    ctx.beginPath();ctx.arc(px,py-8,rI-2,0,Math.PI*2);ctx.fill();
    ctx.restore();
    ctx.save();ctx.translate(px,py-8);
    for(var i=0;i<8;i++){var ang=this.time*3+i*Math.PI/4;ctx.fillStyle=C.W;ctx.beginPath();ctx.arc(Math.cos(ang)*(rI-4),Math.sin(ang)*(rI-4),1.8,0,Math.PI*2);ctx.fill();}
    ctx.restore();
    ctx.fillStyle=idx===0?C.SK:'#ff7aa6';ctx.font='bold 10px sans-serif';ctx.textAlign='center';
    ctx.fillText('SH '+sl.shT.toFixed(1)+'s',px,py-50);
  },

  draw:function(){
    ctx.clearRect(0,0,LW,LH);
    if(this.st===ST.INTRO){
      drawClassBG(ctx);
      new Player(LW/2-60,LH/2+30,0).draw(ctx);
      new Player(LW/2+60,LH/2+30,1).draw(ctx);
    } else {
      drawAbrBG(ctx);
      var self=this;
      this.blasts.forEach(function(s){s.draw(ctx);});
      this.bullets.forEach(function(b){b.draw(ctx);});
      this.heals.forEach(function(it){it.draw(ctx);});
      this.shields.forEach(function(it){it.draw(ctx);});
      this.enemies.forEach(function(e){e.draw(ctx);});
      this.players.forEach(function(p){p.draw(ctx);});
      this.players.forEach(function(p,i){self.drawShieldFX(p,self.slots[i],i);});
      this.parts.forEach(function(p){p.draw(ctx);});
    }
  }
};

// ---- main loop ----
var last=performance.now();
function loop(now){
  try{
    var dt=(now-last)/1000; if(dt>0.05)dt=0.05; last=now;
    game.update(dt); game.draw();
  }catch(e){
    console.error('Game error:',e);
    ctx.fillStyle='#ff4444';ctx.font='bold 14px sans-serif';ctx.textAlign='center';
    ctx.fillText('ERROR: '+e.message,LW/2,LH/2);
  }
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

})();
