#!/usr/bin/env python3
import re, sys

with open('/Users/xuchenrui/Documents/xcr/学校大战_web/game.js', 'r') as f:
    js = f.read()

opens = js.count('{')
closes = js.count('}')
parens_o = js.count('(')
parens_c = js.count(')')
brackets_o = js.count('[')
brackets_c = js.count(']')

print(f'Braces: open={opens} close={closes} diff={opens-closes}')
print(f'Parens: open={parens_o} close={parens_c} diff={parens_o-parens_c}')
print(f'Brackets: open={brackets_o} close={brackets_c} diff={brackets_o-brackets_c}')

if opens != closes:
    # Find the line with mismatched braces
    depth = 0
    for i, line in enumerate(js.split('\n'), 1):
        for ch in line:
            if ch == '{': depth += 1
            elif ch == '}': depth -= 1
        if depth < 0:
            print(f'  NEGATIVE DEPTH at line {i}: depth={depth}')
            print(f'    {line.strip()[:80]}')
    print(f'  Final depth: {depth}')
else:
    print('  Brace balance OK')

if parens_o != parens_c:
    depth = 0
    for i, line in enumerate(js.split('\n'), 1):
        for ch in line:
            if ch == '(': depth += 1
            elif ch == ')': depth -= 1
        if depth < 0:
            print(f'  PAREN NEGATIVE at line {i}: depth={depth}')
            print(f'    {line.strip()[:80]}')
    print(f'  Final paren depth: {depth}')
else:
    print('  Paren balance OK')

# Check for class structure
lines = js.split('\n')
for i, line in enumerate(lines, 1):
    s = line.strip()
    if s.startswith('class ') and '{' in s:
        print(f'Line {i}: {s[:70]}')
    if s.startswith('constructor('):
        print(f'Line {i}: {s[:70]}')
    if s.startswith('update(dt'):
        print(f'Line {i}: {s[:70]}')
    if s.startswith('draw()'):
        print(f'Line {i}: {s[:70]}')

print(f'\nTotal lines: {len(lines)}')
